
# shippingapi.Model.CarrierRule

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ServiceId** | **Services** |  | [optional] 
**BrandedName** | **string** |  | [optional] 
**ParcelTypeRules** | [**List&lt;ParcelTypeRules&gt;**](ParcelTypeRules.md) |  | [optional] 
**Parameters** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

