
# shippingapi.Model.ParcelProtectionPolicyResponseShipmentDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ShipmentDate** | **string** |  | [optional] 
**ShipmentTransactionId** | **string** |  | [optional] 
**ShipmentId** | **string** |  | [optional] 
**ParcelTrackingNumber** | **string** |  | [optional] 
**Carrier** | **string** |  | [optional] 
**Amount** | **string** |  | [optional] 
**PackageLength** | **string** |  | [optional] 
**PackageWidth** | **string** |  | [optional] 
**PackageHeight** | **string** |  | [optional] 
**Weight** | **string** |  | [optional] 
**Zone** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

