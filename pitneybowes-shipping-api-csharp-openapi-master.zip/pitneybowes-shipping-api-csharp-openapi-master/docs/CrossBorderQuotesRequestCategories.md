
# shippingapi.Model.CrossBorderQuotesRequestCategories

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CategoryCode** | **string** |  | [optional] 
**Descriptions** | [**List&lt;CrossBorderQuotesRequestDescriptions&gt;**](CrossBorderQuotesRequestDescriptions.md) |  | [optional] 
**ParentCategoryCode** | **string** |  | [optional] 
**Url** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

