
# shippingapi.Model.Customs

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CustomsInfo** | [**CustomsInfo**](CustomsInfo.md) |  | [optional] 
**CustomsItems** | [**List&lt;CustomsItem&gt;**](CustomsItem.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

