
# shippingapi.Model.ContainerDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CommodityInfo** | [**List&lt;CommodityInfo&gt;**](CommodityInfo.md) |  | [optional] 
**ContainerType** | **string** |  | [optional] 
**PackagingType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

