
# shippingapi.Model.Tax

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DisplayName** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**TaxAmount** | **decimal** |  | [optional] 
**TaxRate** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

