
# shippingapi.Model.CrossBorderQuotesErrorsQuote

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**QuoteCurrency** | **string** |  | [optional] 
**QuoteLines** | [**List&lt;CrossBorderQuotesErrorsQuoteLines&gt;**](CrossBorderQuotesErrorsQuoteLines.md) |  | [optional] 
**Errors** | [**CrossBorderQuotesErrorsErrors**](CrossBorderQuotesErrorsErrors.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

