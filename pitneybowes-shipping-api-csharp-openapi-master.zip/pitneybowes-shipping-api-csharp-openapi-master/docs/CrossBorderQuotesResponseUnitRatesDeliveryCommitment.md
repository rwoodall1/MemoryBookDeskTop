
# shippingapi.Model.CrossBorderQuotesResponseUnitRatesDeliveryCommitment

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MinEstimatedNumberOfDays** | **int** |  | [optional] 
**MaxEstimatedNumberOfDays** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

