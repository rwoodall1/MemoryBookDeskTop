
# shippingapi.Model.ParcelProtectionPolicyResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Content** | [**List&lt;ParcelProtectionPolicyResponseContent&gt;**](ParcelProtectionPolicyResponseContent.md) |  | [optional] 
**Last** | **bool** |  | [optional] 
**TotalElements** | **int** |  | [optional] 
**TotalPages** | **int** |  | [optional] 
**First** | **bool** |  | [optional] 
**NumberOfElements** | **int** |  | [optional] 
**Sort** | [**List&lt;ParcelProtectionPolicyResponseSort&gt;**](ParcelProtectionPolicyResponseSort.md) |  | [optional] 
**Size** | **int** |  | [optional] 
**Number** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

