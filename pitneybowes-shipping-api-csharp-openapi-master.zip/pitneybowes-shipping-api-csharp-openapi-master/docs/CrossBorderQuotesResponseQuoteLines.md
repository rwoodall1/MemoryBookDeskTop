
# shippingapi.Model.CrossBorderQuotesResponseQuoteLines

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LineId** | **string** |  | [optional] 
**ItemId** | **string** |  | [optional] 
**QuoteLineId** | **string** |  | [optional] 
**Quantity** | **int** |  | [optional] 
**UnitRates** | [**CrossBorderQuotesResponseUnitRates**](CrossBorderQuotesResponseUnitRates.md) |  | [optional] 
**LineRates** | [**CrossBorderQuotesResponseLineRates**](CrossBorderQuotesResponseLineRates.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

