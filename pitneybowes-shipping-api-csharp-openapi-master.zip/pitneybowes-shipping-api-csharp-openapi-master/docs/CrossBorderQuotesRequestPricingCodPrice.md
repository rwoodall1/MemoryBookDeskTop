
# shippingapi.Model.CrossBorderQuotesRequestPricingCodPrice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Price** | **int** |  | [optional] 
**Cod** | **string** |  | [optional] 
**IncludesDuty** | **bool** |  | [optional] 
**IncludesTaxes** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

