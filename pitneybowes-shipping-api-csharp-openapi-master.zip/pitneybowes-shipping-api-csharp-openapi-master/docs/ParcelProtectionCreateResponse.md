
# shippingapi.Model.ParcelProtectionCreateResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TransactionID** | **string** |  | [optional] 
**ParcelProtectionReferenceID** | **string** |  | [optional] 
**ParcelProtectionDate** | **string** |  | [optional] 
**ParcelProtectionFees** | **decimal** |  | [optional] 
**ParcelProtectionFeesCurrencyCode** | **string** |  | [optional] 
**ParcelProtectionFeesBreakup** | [**ParcelProtectionCreateResponseParcelProtectionFeesBreakup**](ParcelProtectionCreateResponseParcelProtectionFeesBreakup.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

