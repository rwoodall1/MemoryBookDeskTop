
# shippingapi.Model.ParcelProtectionPolicyResponseShipperInfoAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Street1** | **string** |  | [optional] 
**Street2** | **string** |  | [optional] 
**Street3** | **string** |  | [optional] 
**City** | **string** |  | [optional] 
**Region** | **string** |  | [optional] 
**Country** | **string** |  | [optional] 
**PostalCode** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

