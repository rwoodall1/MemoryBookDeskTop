
# shippingapi.Model.ParcelProtectionQuoteRequestShipmentInfoShipperInfoAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddressLines** | **List&lt;string&gt;** |  | 
**CityTown** | **string** |  | 
**StateProvince** | **string** |  | 
**PostalCode** | **string** |  | 
**CountryCode** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

