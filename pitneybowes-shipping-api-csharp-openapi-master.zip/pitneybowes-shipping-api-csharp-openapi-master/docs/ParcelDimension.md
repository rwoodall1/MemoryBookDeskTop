
# shippingapi.Model.ParcelDimension

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Length** | **decimal** |  | [optional] 
**Height** | **decimal** |  | [optional] 
**Width** | **decimal** |  | [optional] 
**UnitOfMeasurement** | **UnitOfDimension** |  | [optional] 
**IrregularParcelGirth** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

