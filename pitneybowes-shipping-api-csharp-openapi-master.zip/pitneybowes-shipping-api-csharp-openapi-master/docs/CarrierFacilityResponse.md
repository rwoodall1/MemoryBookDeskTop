
# shippingapi.Model.CarrierFacilityResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | [**Address**](Address.md) |  | [optional] 
**Carrier** | **string** |  | [optional] 
**CarrierFacilityOptions** | [**List&lt;CarrierFacilityResponseCarrierFacilityOptions&gt;**](CarrierFacilityResponseCarrierFacilityOptions.md) |  | [optional] 
**CarrierFacilitySuggestions** | [**List&lt;CarrierFacilityResponseCarrierFacilitySuggestions&gt;**](CarrierFacilityResponseCarrierFacilitySuggestions.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

