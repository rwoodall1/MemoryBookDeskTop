
# shippingapi.Model.ServicesParameterRule

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**BrandedName** | **string** |  | [optional] 
**Required** | **bool** |  | [optional] 
**MinValue** | **decimal** |  | [optional] 
**MaxValue** | **decimal** |  | [optional] 
**FreeValue** | **decimal** |  | [optional] 
**Format** | **string** |  | [optional] 
**Description** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

