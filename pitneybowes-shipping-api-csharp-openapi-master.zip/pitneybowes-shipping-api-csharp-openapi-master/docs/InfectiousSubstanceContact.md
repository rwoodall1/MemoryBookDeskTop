
# shippingapi.Model.InfectiousSubstanceContact

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CompanyName** | **string** |  | [optional] 
**ContactId** | **string** |  | [optional] 
**EmailAddress** | **string** |  | [optional] 
**PersonName** | **string** |  | [optional] 
**PhoneNumber** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

