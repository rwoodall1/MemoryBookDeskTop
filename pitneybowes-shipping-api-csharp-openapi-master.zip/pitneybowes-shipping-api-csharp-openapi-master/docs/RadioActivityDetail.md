
# shippingapi.Model.RadioActivityDetail

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CriticalitySafetyIndex** | **decimal** |  | [optional] 
**RadioActiveParcelDimension** | [**RadioActiveParcelDimension**](RadioActiveParcelDimension.md) |  | [optional] 
**SurfaceReading** | **decimal** |  | [optional] 
**TransportIndex** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

