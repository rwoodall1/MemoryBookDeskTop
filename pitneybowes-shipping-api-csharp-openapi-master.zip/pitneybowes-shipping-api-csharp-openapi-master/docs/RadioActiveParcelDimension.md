
# shippingapi.Model.RadioActiveParcelDimension

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UOM** | **string** | unit of measurement | [optional] 
**Height** | **decimal** |  | [optional] 
**Length** | **decimal** |  | [optional] 
**Width** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

