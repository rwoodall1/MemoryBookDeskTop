
# shippingapi.Model.AddTrackingEventsEvents

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EventCode** | **string** |  | [optional] 
**CarrierEventCode** | **string** |  | [optional] 
**EventDate** | **string** |  | [optional] 
**EventTime** | **string** |  | [optional] 
**EventTimeOffset** | **string** |  | [optional] 
**EventCity** | **string** |  | [optional] 
**EventStateOrProvince** | **string** |  | [optional] 
**PostalCode** | **string** |  | [optional] 
**Country** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

