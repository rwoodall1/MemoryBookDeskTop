
# shippingapi.Model.TrackingAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**Address1** | **string** |  | [optional] 
**Address2** | **string** |  | [optional] 
**Address3** | **string** |  | [optional] 
**City** | **string** |  | [optional] 
**StateOrProvince** | **string** |  | [optional] 
**PostalCode** | **int** |  | [optional] 
**Country** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

