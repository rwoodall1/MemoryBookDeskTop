
# shippingapi.Model.CrossBorderQuotesResponseQuote

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**QuoteCurrency** | **string** |  | [optional] 
**QuoteLines** | [**List&lt;CrossBorderQuotesResponseQuoteLines&gt;**](CrossBorderQuotesResponseQuoteLines.md) |  | [optional] 
**TotalPrice** | **decimal** |  | [optional] 
**TotalRates** | [**CrossBorderQuotesResponseTotalRates**](CrossBorderQuotesResponseTotalRates.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

