
# shippingapi.Model.DocumentPage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Contents** | **string** | base64 | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

