
# shippingapi.Model.TrackingResponseScanDetailsList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EventDate** | **DateTime** |  | [optional] 
**EventTime** | **string** |  | [optional] 
**EventCity** | **string** |  | [optional] 
**EventStateOrProvince** | **string** |  | [optional] 
**PostalCode** | **int** |  | [optional] 
**Country** | **string** |  | [optional] 
**ScanType** | **string** |  | [optional] 
**ScanDescription** | **string** |  | [optional] 
**PackageStatus** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

