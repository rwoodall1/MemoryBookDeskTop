
# shippingapi.Model.CrossBorderQuotesResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Quote** | [**List&lt;CrossBorderQuotesResponseQuote&gt;**](CrossBorderQuotesResponseQuote.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

