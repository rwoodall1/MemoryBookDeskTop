
# shippingapi.Model.ParcelProtectionQuoteRequestShipmentInfoParcelInfoCommodityList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CategoryPath** | **string** |  | 
**ItemCode** | **string** |  | 
**Name** | **string** |  | 
**Url** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

