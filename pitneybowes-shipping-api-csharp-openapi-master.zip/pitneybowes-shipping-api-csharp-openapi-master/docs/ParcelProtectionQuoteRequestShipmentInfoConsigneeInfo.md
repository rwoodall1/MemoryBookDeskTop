
# shippingapi.Model.ParcelProtectionQuoteRequestShipmentInfoConsigneeInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | [**ParcelProtectionQuoteRequestShipmentInfoShipperInfoAddress**](ParcelProtectionQuoteRequestShipmentInfoShipperInfoAddress.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

