
# shippingapi.Model.SpecialService

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Fee** | **decimal** |  | [optional] 
**InputParameters** | [**List&lt;Parameter&gt;**](Parameter.md) |  | [optional] 
**SpecialServiceId** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

