
# shippingapi.Model.RadioNuclideDetail

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ChemicalForm** | **string** |  | [optional] 
**ExpectedPackageReportableQuantity** | **bool** |  | [optional] 
**PhysicalForm** | **string** |  | [optional] 
**RadioNuclide** | **string** |  | [optional] 
**RadioNuclideActivityUOM** | **string** |  | [optional] 
**RadioNuclideActivityValue** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

