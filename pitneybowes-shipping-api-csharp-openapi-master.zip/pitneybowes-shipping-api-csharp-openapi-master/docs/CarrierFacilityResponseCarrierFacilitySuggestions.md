
# shippingapi.Model.CarrierFacilityResponseCarrierFacilitySuggestions

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | [**Address**](Address.md) |  | [optional] 
**CarrierFacilityAttributes** | [**List&lt;CarrierFacilityResponseCarrierFacilityOptions&gt;**](CarrierFacilityResponseCarrierFacilityOptions.md) |  | [optional] 
**FacilityHours** | [**List&lt;CarrierFacilityResponseFacilityHours&gt;**](CarrierFacilityResponseFacilityHours.md) |  | [optional] 
**FacilityParking** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

