
# shippingapi.Model.PageRealTransactionDetailReport

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Content** | [**List&lt;RealTransactionDetailReport&gt;**](RealTransactionDetailReport.md) |  | [optional] 
**First** | **bool** |  | [optional] 
**Last** | **bool** |  | [optional] 
**Number** | **int** |  | [optional] 
**NumberOfElements** | **int** |  | [optional] 
**Size** | **int** |  | [optional] 
**TotalElements** | **long** |  | [optional] 
**TotalPages** | **int** |  | [optional] 
**SearchCriteria** | [**SearchCriteria**](SearchCriteria.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

