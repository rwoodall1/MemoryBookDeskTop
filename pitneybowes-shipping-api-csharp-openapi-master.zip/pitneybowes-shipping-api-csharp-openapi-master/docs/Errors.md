
# shippingapi.Model.Errors

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdditionalInfo** | **string** | additionalInfo | [optional] 
**ErrorCode** | **string** | errorCode | [optional] 
**Message** | **string** | message | [optional] 
**MoreInfo** | **string** | moreInfo | [optional] 
**Parameters** | **List&lt;string&gt;** | parameters | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

