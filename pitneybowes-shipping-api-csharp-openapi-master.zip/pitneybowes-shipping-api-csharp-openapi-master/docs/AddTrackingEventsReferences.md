
# shippingapi.Model.AddTrackingEventsReferences

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ReferenceType** | **string** |  | [optional] 
**ReferenceValue** | **string** |  | [optional] 
**Events** | [**List&lt;AddTrackingEventsEvents&gt;**](AddTrackingEventsEvents.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

