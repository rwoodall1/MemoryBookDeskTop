
# shippingapi.Model.CarrierPayment

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccountNumber** | **string** |  | [optional] 
**CountryCode** | **string** |  | [optional] 
**Party** | **string** |  | 
**PostalCode** | **string** |  | [optional] 
**TypeOfCharge** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

