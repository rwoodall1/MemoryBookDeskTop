
# shippingapi.Model.DeliveryCommitment

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdditionalDetails** | **string** |  | [optional] 
**EstimatedDeliveryDateTime** | **string** |  | [optional] 
**Guarantee** | **string** |  | [optional] 
**MaxEstimatedNumberOfDays** | **string** |  | [optional] 
**MinEstimatedNumberOfDays** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

