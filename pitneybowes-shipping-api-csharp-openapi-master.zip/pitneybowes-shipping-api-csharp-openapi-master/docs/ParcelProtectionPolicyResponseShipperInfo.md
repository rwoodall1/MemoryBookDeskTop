
# shippingapi.Model.ParcelProtectionPolicyResponseShipperInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ShipperID** | **string** |  | [optional] 
**FirstName** | **string** |  | [optional] 
**MiddleName** | **string** |  | [optional] 
**LastName** | **string** |  | [optional] 
**Company** | **string** |  | [optional] 
**Email** | **string** |  | [optional] 
**PhoneNumber1** | **string** |  | [optional] 
**PhoneNumber2** | **string** |  | [optional] 
**FaxNumber** | **string** |  | [optional] 
**Address** | [**ParcelProtectionPolicyResponseShipperInfoAddress**](ParcelProtectionPolicyResponseShipperInfoAddress.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

