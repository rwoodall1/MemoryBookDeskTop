
# shippingapi.Model.ParcelProtectionQuoteRequestShipmentInfoParcelInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CommodityList** | [**List&lt;ParcelProtectionQuoteRequestShipmentInfoParcelInfoCommodityList&gt;**](ParcelProtectionQuoteRequestShipmentInfoParcelInfoCommodityList.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

