
# shippingapi.Model.CarrierFacilityRequestAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddressLines** | **List&lt;string&gt;** |  | [optional] 
**CityTown** | **string** |  | [optional] 
**StateProvince** | **string** |  | [optional] 
**CountryCode** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

