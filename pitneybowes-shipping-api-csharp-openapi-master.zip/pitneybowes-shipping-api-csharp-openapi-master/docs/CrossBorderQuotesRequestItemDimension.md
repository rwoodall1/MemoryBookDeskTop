
# shippingapi.Model.CrossBorderQuotesRequestItemDimension

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Length** | **int** |  | [optional] 
**Height** | **decimal** |  | [optional] 
**Width** | **int** |  | [optional] 
**UnitOfMeasurement** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

