
# shippingapi.Model.WeightRules

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Required** | **bool** |  | [optional] 
**UnitOfMeasurement** | **string** |  | [optional] 
**MinWeight** | **decimal** |  | [optional] 
**MaxWeight** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

