
# shippingapi.Model.SchedulePickupPickupSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ServiceId** | **string** |  | [optional] 
**Count** | **int** |  | [optional] 
**TotalWeight** | [**SchedulePickupTotalWeight**](SchedulePickupTotalWeight.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

