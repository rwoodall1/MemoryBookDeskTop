
# shippingapi.Model.CrossBorderQuotesRequestPricing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Price** | **int** |  | [optional] 
**CodPrice** | [**List&lt;CrossBorderQuotesRequestPricingCodPrice&gt;**](CrossBorderQuotesRequestPricingCodPrice.md) |  | [optional] 
**DutiableValue** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

