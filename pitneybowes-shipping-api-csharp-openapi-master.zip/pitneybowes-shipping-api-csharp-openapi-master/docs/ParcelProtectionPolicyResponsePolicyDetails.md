
# shippingapi.Model.ParcelProtectionPolicyResponsePolicyDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PolicyId** | **string** |  | [optional] 
**PolicyDate** | **string** |  | [optional] 
**PolicyStatus** | **string** |  | [optional] 
**ClaimStatus** | **string** |  | [optional] 
**ClaimStatusUpdateDate** | **string** |  | [optional] 
**ValueOfGoods** | **decimal** |  | [optional] 
**InsuranceValue** | **decimal** |  | [optional] 
**PremiumValue** | **decimal** |  | [optional] 
**BasePremium** | **decimal** |  | [optional] 
**TechnologyFee** | **decimal** |  | [optional] 
**CurrencyCode** | **string** |  | [optional] 
**MailClass** | **string** |  | [optional] 
**MailClassOption** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

