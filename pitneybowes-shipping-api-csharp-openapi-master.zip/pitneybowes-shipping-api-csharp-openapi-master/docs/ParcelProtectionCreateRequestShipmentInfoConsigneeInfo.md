
# shippingapi.Model.ParcelProtectionCreateRequestShipmentInfoConsigneeInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | [**Address**](Address.md) |  | [optional] 
**CompanyName** | **string** |  | [optional] 
**FamilyName** | **string** |  | [optional] 
**GivenName** | **string** |  | [optional] 
**MiddleName** | **string** |  | [optional] 
**Email** | **string** |  | [optional] 
**PhoneNumbers** | **List&lt;Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

