
# shippingapi.Model.ParcelProtectionCreateRequestShipmentInfoShipperInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ShipperID** | **string** |  | [optional] 
**Address** | [**ParcelProtectionCreateRequestShipmentInfoShipperInfoAddress**](ParcelProtectionCreateRequestShipmentInfoShipperInfoAddress.md) |  | [optional] 
**CompanyName** | **string** |  | [optional] 
**FamilyName** | **string** |  | [optional] 
**GivenName** | **string** |  | [optional] 
**MiddleName** | **string** |  | [optional] 
**Email** | **string** |  | [optional] 
**PhoneNumbers** | **List&lt;Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

