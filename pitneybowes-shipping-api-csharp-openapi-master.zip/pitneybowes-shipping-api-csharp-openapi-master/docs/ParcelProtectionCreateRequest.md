
# shippingapi.Model.ParcelProtectionCreateRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ParcelProtectionAccountID** | **string** |  | [optional] 
**ParcelProtectionProgramID** | **string** |  | [optional] 
**ShipmentInfo** | [**ParcelProtectionCreateRequestShipmentInfo**](ParcelProtectionCreateRequestShipmentInfo.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

